//Link: https://firebase.google.com/docs/database/web/start
// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDHogwl8u-Rd48w38VO5PcScAheiKU63qk",
    authDomain: "iot-cb-f926d.firebaseapp.com",
    projectId: "iot-cb-f926d",
    storageBucket: "iot-cb-f926d.firebasestorage.app",
    messagingSenderId: "181583594072",
    appId: "1:181583594072:web:e3401eab17cf1d4022402d"
  };

  // Initialize Firebase
    firebase.initializeApp(firebaseConfig);

// Initialize Realtime Database and get a reference to the service
    const database = firebase.database();

// Khai báo biến và liên kết thẻ bên HTML
    const led01_on = document.getElementById("led01_on");
    const led01_off = document.getElementById("led01_off");
    const light01 = document.getElementById("light01");

// TỰ ĐỘNG cập nhật dữ liệu từ firebase
    const temp = document.getElementById("temp");
    database.ref("/TT_IoT/Temp").on("value",function(snapshot){
    let t= snapshot.val();
    temp.innerHTML = t;
    console.log();
})

// TỰ ĐỘNG CẬP NHẬT DỮ LIỆU TỪ FIREBASE CHO BULD
    database.ref("/TT_IoT/BULB_01").on("value",function(snapshot){
    let t= snapshot.val();
    if (t==0)
        light01.src ="./img/light_off.jpg"
    else
    light01.src ="./img/light_on.jpg"
})

//// CÁCH KHÁC CÓ THỂ DÙNG ĐỂ TỰ ĐỘNG CẬP NHẬT DỮ LIỆU TỪ FIREBASE CHO BULD 

//database.ref("/TT_IoT").on("value",function(snapshot){
   // let t= snapshot.val(); // Array {key:value, key:value,...}
   // console.log(t);
   //
   // if(t["BULD_01"]==0)
  //    light01.src ="./img/light_off.jpg"
 // else
//      light01.src ="./img/light_on.jpg"
//})

// Xử Lý sự kiện ĐÈN 1
    led01_on.onclick = function(){
    light01.src ="./img/light_on.jpg";

    // Cập nhật firebase
    database.ref("/TT_IoT").update({
        "BULB_01" : 1
    })
}
    led01_off.onclick = function(){
    light01.src ="./img/light_off.jpg";

    // Cập nhật firebase
    database.ref("/TT_IoT").update({
        "BULB_01" : 0
    })
    
    // TỰ ĐỘNG CẬP NHẬT DỮ LIỆU TỪ FIREBASE CHO BULD ĐÈN 01
    database.ref("/TT_IoT/BULB_01").on("value",function(snapshot){
    let t= snapshot.val();
    if (t==0)
        light01.src ="./img/light_off.jpg"
    else
    light01.src ="./img/light_on.jpg"
})

}
// Xử Lý sự kiện ĐÈN 2
    led02_on.onclick = function(){
    light02.src ="./img/light_on.jpg";

    // Cập nhật firebase
    database.ref("/TT_IoT").update({
        "BULB_02" : 1
    })
}
    led02_off.onclick = function(){
    light02.src ="./img/light_off.jpg";

    // Cập nhật firebase
    database.ref("/TT_IoT").update({
        "BULB_02" : 0
    })
    
}

// TỰ ĐỘNG CẬP NHẬT DỮ LIỆU TỪ FIREBASE CHO BULD ĐÈN 02
database.ref("/TT_IoT/BULB_02").on("value",function(snapshot){
    let t= snapshot.val();
    if (t==0)
        light02.src ="./img/light_off.jpg"
    else
    light02.src ="./img/light_on.jpg"
})

// Xử Lý sự kiện ĐÈN 3
led03_on.onclick = function(){
    light03.src ="./img/light_on.jpg";

    // Cập nhật firebase
    database.ref("/TT_IoT").update({
        "BULB_03" : 1
    })
}
    led03_off.onclick = function(){
    light03.src ="./img/light_off.jpg";

    // Cập nhật firebase
    database.ref("/TT_IoT").update({
        "BULB_03" : 0
    })  
}

// TỰ ĐỘNG CẬP NHẬT DỮ LIỆU TỪ FIREBASE CHO BULD ĐÈN 02
database.ref("/TT_IoT/BULB_03").on("value",function(snapshot){
    let t= snapshot.val();
    if (t==0)
        light03.src ="./img/light_off.jpg"
    else
    light03.src ="./img/light_on.jpg"
})
// Xử Lý sự kiện ĐÈN 4
led04_on.onclick = function(){
    light04.src ="./img/light_on.jpg";

    // Cập nhật firebase
    database.ref("/TT_IoT").update({
        "BULB_04" : 1
    })
}
    led04_off.onclick = function(){
    light04.src ="./img/light_off.jpg";

    // Cập nhật firebase
    database.ref("/TT_IoT").update({
        "BULB_04" : 0
    })  
}

// TỰ ĐỘNG CẬP NHẬT DỮ LIỆU TỪ FIREBASE CHO BULD ĐÈN 04
database.ref("/TT_IoT/BULB_04").on("value",function(snapshot){
    let t= snapshot.val();
    if (t==0)
        light04.src ="./img/light_off.jpg"
    else
    light04.src ="./img/light_on.jpg"
})
// Xử Lý sự kiện ĐÈN 5
led05_on.onclick = function(){
    light05.src ="./img/light_on.jpg";

    // Cập nhật firebase
    database.ref("/TT_IoT").update({
        "BULB_05" : 1
    })
}
    led05_off.onclick = function(){
    light05.src ="./img/light_off.jpg";

    // Cập nhật firebase
    database.ref("/TT_IoT").update({
        "BULB_05" : 0
    })  
}

// TỰ ĐỘNG CẬP NHẬT DỮ LIỆU TỪ FIREBASE CHO BULD ĐÈN 05
database.ref("/TT_IoT/BULD_05").on("value",function(snapshot){
    let t= snapshot.val();
    if (t==0)
        light05.src ="./img/light_off.jpg"
    else
    light05.src ="./img/light_on.jpg"
})
// Xử Lý sự kiện ĐÈN 6
led06_on.onclick = function(){
    light06.src ="./img/light_on.jpg";

    // Cập nhật firebase
    database.ref("/TT_IoT").update({
        "BULB_06" : 1
    })
}
    led06_off.onclick = function(){
    light06.src ="./img/light_off.jpg";

    // Cập nhật firebase
    database.ref("/TT_IoT").update({
        "BULB_06" : 0
    })  
}

// TỰ ĐỘNG CẬP NHẬT DỮ LIỆU TỪ FIREBASE CHO BULD ĐÈN 06
database.ref("/TT_IoT/BULB_06").on("value",function(snapshot){
    let t= snapshot.val();
    if (t==0)
        light06.src ="./img/light_off.jpg"
    else
    light06.src ="./img/light_on.jpg"
})