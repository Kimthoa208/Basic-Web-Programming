
const led01_on = document.getElementById("led01_on");
const led01_off = document.getElementById("led01_off");
const light01 = document.getElementById("light01");


led01_on.onclick = function(){
    light01.src = "./img/light_on.jpg";
    database.ref("/TT_IoT").update({
        "BULB_01" : 1
    })
}
led01_off.onclick = function(){
    light01.src = "./img/light_off.jpg";
    database.ref("/TT_IoT").update({
        "BULB_01" : 0
    })
}
led02_on.onclick = function(){
    light02.src = "./img/light_on.jpg";
    database.ref("/TT_IoT").update({
        "BULB_02" : 1
    })
}
led02_off.onclick = function(){
    light02.src = "./img/light_off.jpg";
    database.ref("/TT_IoT").update({
        "BULB_02" : 0
    })
}
led03_on.onclick = function(){
    light03.src = "./img/light_on.jpg";
    database.ref("/TT_IoT").update({
        "BULB_03" : 1
    })
}
led03_off.onclick = function(){
    light03.src = "./img/light_off.jpg";
    database.ref("/TT_IoT").update({
        "BULB_03" : 0
    })
}
led04_on.onclick = function(){
    light04.src = "./img/light_on.jpg";
    database.ref("/TT_IoT").update({
        "BULB_04" : 1
    })
}
led04_off.onclick = function(){
    light04.src = "./img/light_off.jpg";
    database.ref("/TT_IoT").update({
        "BULB_04" : 0
    })
}
led05_off.onclick = function(){
    light05.src = "./img/light_off.jpg";
    database.ref("/TT_IoT").update({
        "BULB_05" : 0
    })
}
led05_on.onclick = function(){
    light05.src = "./img/light_on.jpg";
    database.ref("/TT_IoT").update({
        "BULB_05" : 1
    })
}
led06_off.onclick = function(){
    light06.src = "./img/light_off.jpg";
    database.ref("/TT_IoT").update({
        "BULB_06" : 0
    })
}
led06_on.onclick = function(){
    light06.src = "./img/light_on.jpg";
    database.ref("/TT_IoT").update({
        "BULB_06" : 1
    })
}

